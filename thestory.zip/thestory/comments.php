<?php 
/**
* Comments template.
*/

if ( post_password_required() ){
	return;
}
?>
<div id="comments">
<?php
if(have_comments()){ ?>
<h4 class="comments-titile">
	<?php comments_number(__( 'No comments', 'pexeto' ), __('One comment', 'pexeto'), '% '.__( 'comments', 'pexeto' )); ?>
</h4>
<?php } //end if have comments ?>
<div id="comment-content-container">
<?php if(have_comments()){?>
<ul class="commentlist">
<?php wp_list_comments(array(
		'type'=>'all',
		'callback'=>'pexeto_comments')); ?>
</ul>
<div class="comment-navigation">
	<div class="alignleft">
		<?php next_comments_link('<span>&laquo;</span> '.__('Newer comments', 'pexeto')); ?>
	</div>
	<div class="alignright">
		<?php previous_comments_link(__('Older comments', 'pexeto').' <span>&raquo;</span>') ?>
	</div>
</div>
<?php } //end if have comments 

$args=array();
$args['comment_notes_before']='<div class="double-line"></div>';
$args['comment_notes_after']='';
$args['title_reply']=__( 'Leave a comment', 'pexeto' );
$args['label_submit']=__( 'Submit comment', 'pexeto' );
$args['logged_in_as']='';
$args['title_reply_to']=__( 'Leave a reply to', 'pexeto' ).' %s';
$args['cancel_reply_link']=__( 'Cancel reply', 'pexeto' );


pexeto_add_comment_label_filters();
comment_form( $args ); 
pexeto_remove_comment_label_filters();

?>
</div>
</div>
