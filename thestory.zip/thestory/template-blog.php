<?php
/**
 * Template Name: Blog page
 */
get_header();

if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		//get all the page meta data (settings) needed (function located in functions/meta.php)
		$pexeto_page = pexeto_get_post_meta( $post->ID, array( 'slider', 'header_display', 'sidebar', 'blog_layout' ) );
		$pexeto_blog = new PexetoBlog($post->ID);


		$pexeto_page['layout'] = $pexeto_blog->layout;
		if(isset($pexeto_blog->columns)){
			$pexeto_page['columns'] = $pexeto_blog->columns;
		}

		//include the before content template
		locate_template( array( 'includes/html-before-content.php' ), true, true );

		the_content();
	}
}

query_posts( $pexeto_blog->query_args );

if ( have_posts() ) {

	if ( $pexeto_blog->masonry ) {
		//it is a multi-column layout, wrap the content into a masonry div
		?><div id="blog-masonry" class="page-masonry"><?php
	}
	while ( have_posts() ) {
		the_post();
		global $more;
		$more = 0;

		//include the post template
		locate_template( array( 'includes/post-template.php' ), true, false );
	}

	if ( $pexeto_blog->masonry ) {
		?></div><?php
	}


	locate_template( array( 'includes/post-pagination.php' ), true, false );

}else {
	_e( 'No posts available', 'pexeto' );
}

//reset the inital page query
wp_reset_query();
wp_reset_postdata();

//include the after content template
locate_template( array( 'includes/html-after-content.php' ), true, true );

get_footer();
?>
