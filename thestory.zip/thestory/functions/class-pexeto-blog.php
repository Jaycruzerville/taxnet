<?php

if(!class_exists('PexetoBlog')){
	
	/**
	 * Includes the main Blog page functionality - sets the post query,
	 * and the general page options.
	 */
	class PexetoBlog{
		
		public $query_args = array();
		public $masonry = false;
		public $layout;
		public $columns;
		
		protected $meta;
		protected $page_id;
		public static $cat_key = 'show';
		
		public function __construct($page_id){
			$this->page_id = $page_id;
			$this->init();
		}
		
		protected function init(){
			//get the page meta
			$this->meta = pexeto_get_post_meta( $this->page_id, 
				array( 'slider', 'blog_layout', 'header_display', 'sidebar', 
				'post_number', 'exclude_cats', 'filter_action', 'blog_show_filter' ) );
				
			$this->setup_layout_options();
			$this->setup_query_args();
			
			if($this->category_filter_enabled()){
				$this->setup_category_filters();
			}
			
		}
		
		/**
		 * Checks if category filter is enabled.
		 * @return bool true if it is enabled and false otherwise
		 */
		protected function category_filter_enabled(){
			return $this->meta['blog_show_filter'] == 'true';
		}
		
		/**
		 * Sets the page layout options.
		 */
		protected function setup_layout_options(){
			$column_options = array(
				'twocolumn' => array('columns'=>2, 'layout'=>'full'),
				'threecolumn' => array('columns'=>3, 'layout'=>'full'),
				'twocolumn-left' => array('columns'=>2, 'layout'=>'left'),
				'twocolumn-right' => array('columns'=>2, 'layout'=>'right')
			);
	
			if ( isset($column_options[$this->meta['blog_layout']]) ) {
				//it's a masonry layout
				global $pexeto_scripts;
				$this->masonry = true;
				$pexeto_scripts['blog_masonry']=true;
				
				$layout_options = $column_options[$this->meta['blog_layout']];
				$pexeto_scripts['blog_masonry_cols'] = $layout_options['columns'];
				
				$this->layout = $layout_options['layout'];
				$this->columns = $layout_options['columns'];
			}else {
				//it's a standard layout
				$this->layout = $this->meta['blog_layout'];
			}
		}
		
		/**
		 * Sets the posts query options.
		 */
		protected function setup_query_args(){
			//set the main post arguments
			$this->query_args = array(
				'post_type'=>'post',
				'posts_per_page'=>$this->meta['post_number']
			);
			
			$this->setup_pagination_query();
			$this->setup_category_query();
			
			
			$this->query_args = apply_filters('pexeto_blog_args', $this->query_args);
		}
		
		/**
		 * Sets the pagination options for the post query.
		 */
		protected function setup_pagination_query(){
			$paged = get_query_var( 'paged' );
			if(empty($paged)){
				$paged = get_query_var( 'page' );
			}
			
			if(!empty($paged)){
				$this->query_args['paged'] = $paged;
			}
		}
		
		/**
		 * Loads the category options - which categories to include/exclude and
		 * how to inlude/exclude them.
		 * @return array the category options
		 */
		protected function get_category_options(){
			//include or exclude categories
			//we use exclude_cats key because the first version of the theme used to support
			//exclude only and we use the same option for backwards compatibility
			if ( isset( $this->meta['exclude_cats'] ) && !empty( $this->meta['exclude_cats'] ) ) {
				$cats = array_map('intval', explode( ',', $this->meta['exclude_cats'] ));
				
				$action = isset($this->meta['filter_action']['type']) && 
					$this->meta['filter_action']['type'] == 'include' ? 'include' : 'exclude';
					
				$include_children = isset($this->meta['filter_action']['include_children']) && 
					$this->meta['filter_action']['include_children'] == 'true' ? true : false;
					
				return array(
					'cats' => $cats,
					'action' => $action,
					'apply_to_children' => $include_children
				);
			}
		}
		
		/**
		 * Sets the category options for the post query.
		 */
		protected function setup_category_query(){
			
			$cat_options = $this->get_category_options();
			$current_cat = $this->get_filter_category();
			$tax_queries = array();
			
			if($this->category_filter_enabled() && $current_cat !== null){
				//the category filter is enabled and a category has been selected
				
				$tax_queries[]= array(
					'taxonomy' => 'category',
					'field' => 'id',
					'terms' => $current_cat->term_id
				);
				
			}
				
			if(!empty($cat_options) && is_array($cat_options)){
				//apply the default category options
				$tax_query = array(
					'taxonomy' => 'category',
					'field' => 'id',
					'terms' => $cat_options['cats'],
					'include_children' => $cat_options['apply_to_children']
				);
				
				$tax_query['operator'] = $cat_options['action'] == 'include' ? 'IN' : 'NOT IN';
				$tax_queries[] = $tax_query;
			}
			
			if(!empty($tax_queries)){
				$this->query_args['tax_query'] = $tax_queries;
			}
			
			
		}
		
		/**
		 * Add an action to display the category filter.
		 */
		protected function setup_category_filters(){
			add_action('pexeto_before_content_container', array($this, 'print_category_filter'));
		}
		
		/**
		 * Retrieves the categories that should be displayed in the filter,
		 * based on the default category settings for the page.
		 * @return array the categories as WP term objects array
		 */
		protected function get_filter_categories(){
			$cat_options = $this->get_category_options();
			$args = array('hide_empty'=>true);
			
			if(!empty($cat_options)){
				if($cat_options['action'] == 'include'){
					$filter = 'include';
					$args['hierarchical'] = $cat_options['apply_to_children'];
				}else{
					$filter = $cat_options['apply_to_children'] ? 'exclude_tree' : 'exclude';
				}
				
				$args[$filter] = $cat_options['cats'];
			}
			
			return get_terms('category', $args);
		}
		
		/**
		 * Prints the markup for the category filter.
		 */
		public function print_category_filter(){
			$cats = $this->get_filter_categories();
			$page_url = get_permalink($this->page_id);
			
			?>
			<div class="pg-navigation blog-filter">
				<div class="pg-nav-wrapper content-boxed">
					<!-- <span class="mob-nav-btn blog-filter-nav-btn"><?php echo $this->get_current_cat_name(); ?></span> -->
					
					<div class="pg-cat-filter">
						<div class="pg-filter-btn blog-filter-nav-btn">
							<span><?php echo $this->get_current_cat_name(); ?></span>
						</div>
						<ul>
						<li>
							<a data-cat="-1" href="<?php echo esc_url( $page_url ); ?>" <?php echo $this->get_current_cat_class(); ?>><?php _e( 'All', 'pexeto' ); ?></a>
						</li>
						<?php foreach ($cats as $c){ ?>
							<li>
								<a href="<?php echo esc_url (add_query_arg( self::$cat_key, $c->slug, $page_url ) ); ?>" <?php echo $this->get_current_cat_class($c->slug); ?>>
									<?php echo $c->name; ?></a>
							</li>
						<?php } ?>
						</ul>
					</div>
				</div>
			</div>
			<?php
		}
		
		/**
		 * Returns an HTML snippet setting the current class for a category
		 * if this is the currently selected category.
		 */
		protected function get_current_cat_class($slug = null){
			if($slug == $this->get_filter_category_slug()){
				return 'class="current"';
			}
			
			return '';
		}
		
		/**
		 * Retrieves the slug of the currently selected category.
		 * @return mixed the category slug if a category has been selected or
		 * null otherwise
		 */
		protected function get_filter_category_slug(){
			return isset($_GET[self::$cat_key]) ? $_GET[self::$cat_key] : null;
		}
		
		/**
		 * Retrieves the category object of the currently selected category.
		 * @return mixed WP_Term object if a category has been selected or
		 * null otherwise.
		 */
		protected function get_filter_category(){
			$slug = $this->get_filter_category_slug();
			
			if($slug !== null){
				$cat = get_term_by('slug', $slug, 'category');
				if(!empty($cat)){
					return $cat;
				}
			}
		}
		
		/**
		 * Retrieves the name of the currently selected category.
		 * @return mixed the category name if a category has been selected or
		 * null otherwise
		 */
		protected function get_current_cat_name(){
			$cat = $this->get_filter_category();
			if($cat !== null){
				return $cat->name;
			}else{
				return __('All', 'pexeto');
			}
		}
		
	}
}