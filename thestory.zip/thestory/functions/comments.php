<?php
/**
 * This file contains the comments functionality.
 * @author Pexeto
 */


if(!function_exists('pexeto_comments')){
	/**
	 * Displays a single comment.
	 */
	function pexeto_comments($comment, $args, $depth) {
		?>
	<li <?php comment_class(); ?>>
		<div class="comment-container" id="comment-<?php comment_ID() ?>">
			<div class="comment-box">
				<div class="comment-info">
					<?php if($comment->comment_type=='pingback'){ ?>
						<span class="ping-title"><?php _e('Pingback:', 'pexeto'); ?> </span>
					<?php } ?>
					<span class="coment-autor-name"><?php printf('<cite class="fn">%s</cite>', get_comment_author_link()) ?></span>
					<span class="comment-date"><?php echo get_comment_date(get_option('date_format')); ?> &nbsp;  </span>
			
					<span class="reply">
						<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'reply_text'=>__( 'Reply', 'pexeto' ).' &rarr;')));?></span>
				</div>	
				<div class="clear"></div>	
				<div class="comment-wrapper">
				<div class="comment-autor"><?php echo get_avatar($comment,$size='80',$default='' ); ?></div>
					<?php if($comment->comment_type!='pingback'){ ?>
						<div class="comment-text"><?php comment_text(); ?></div>
					<?php } ?>
					
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<?php
	}
}

/**
 * With the functions below we attempt to replace the default WordPress texts in
 * the comment form, so that all of the front-end texts can be changed from the same place
 * (with the theme's translation file). In this way, if a WordPress translation
 * is missing for the selected language, you can still use the theme's translation file
 * to change the texts.
 */

if(!function_exists('pexeto_set_label_matches')){
	function pexeto_set_label_matches(){
		global $pexeto;

		if(empty($pexeto->comment_label_matches)){
			$pexeto->comment_label_matches = array(
				'Name' =>  __( 'Name', 'pexeto' ),
				'Email' => __( 'E-mail', 'pexeto' ),
				'Website' => __( 'Website', 'pexeto' ),
				'Comment' => __( 'Your comment', 'pexeto' ),
				'Save my name, email, and website in this browser for the next time I comment.' => __('Save my name, email, and website in this browser for the next time I comment.', 'pexeto')
			);
		}
	}
}

if(!function_exists('pexeto_add_comment_label_filters')){
	function pexeto_add_comment_label_filters(){
		pexeto_set_label_matches();

		add_filter('gettext', 'pexeto_filter_comment_texts', 10, 3);
		add_filter('gettext_with_context', 'pexeto_filter_your_comment_text', 10, 4);
	}
}

if(!function_exists('pexeto_remove_comment_label_filters')){
	function pexeto_remove_comment_label_filters(){
		remove_filter('gettext', 'pexeto_filter_comment_texts', 10);
		remove_filter('gettext_with_context', 'pexeto_filter_your_comment_text', 10);
	}
}

if(!function_exists('pexeto_filter_comment_texts')){
	function pexeto_filter_comment_texts($translation, $text, $domain){
		global $pexeto;
		$matches = $pexeto->comment_label_matches;

		if(isset($matches[$text]) && $domain === 'default'){
			return $matches[$text];
		}

		return $translation;
	}
}

if(!function_exists('pexeto_filter_your_comment_text')){
	function pexeto_filter_your_comment_text($translation, $text, $context, $domain){
		global $pexeto;

		if($text == 'Comment' && $context == 'noun' && $domain == 'default'){
			return $pexeto->comment_label_matches['Comment'];
		}

		return $translation;
	}
}