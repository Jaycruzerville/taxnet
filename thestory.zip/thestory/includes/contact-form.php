<form method="post" id="submit-form" class="pexeto-contact-form">
	<div class="error-box error-message"></div>
	<div class="info-box sent-message"></div>
	<div class="contact-form-input contact-input-wrapper">
		<label class="contact-label">
			<?php _e( 'Name', 'pexeto' );;?>
			<span class="mandatory">*</span>
		</label>
		<input type="text" name="name" class="required" />
	</div>

	<div class="contact-form-input contact-input-wrapper">
		<label class="contact-label">
			<?php _e( 'E-mail address', 'pexeto' );?>
			<span class="mandatory">*</span>
		</label>
		<input type="text" name="email" class="required email" />
	</div>

	<div class="contact-form-textarea contact-input-wrapper">
		<label class="contact-label">
			<?php _e( 'Your message', 'pexeto' ); ?>
			<span class="mandatory">*</span>
		</label>
		<textarea name="question" class="required"></textarea>
	</div>

	<?php
	if( pexeto_option('contact_privacy_checkbox') === true){
		?>
		<div class="contact-input-wrapper contact-privacy-wrapper">
			<input type="checkbox" name="privacy_consent" value="accepted" class="required" />
			<span class="contact-privacy-message"><?php echo pexeto_option('contact_privacy_message'); ?></span>
		</div>
		<?php
	}
	
	?>

	<?php if ( PexetoRecaptcha::is_enabled() ) {
		//print the reCAPTCHA widget
		$recaptcha_api_keys = PexetoRecaptcha::get_api_keys();
		?>
		<div id="pexeto-recaptcha">
			<div class="g-recaptcha" data-sitekey="<?php echo $recaptcha_api_keys['site']; ?>"
				data-theme="<?php echo pexeto_option('captcha_v2_theme'); ?>"></div>
		</div>
	<?php } ?>

	<a class="button send-button">
		<span><?php _e( 'Send Message', 'pexeto' ); ?></span>
	</a>
	<div class="contact-loader"></div>
	<div class="clear"></div>
</form>
